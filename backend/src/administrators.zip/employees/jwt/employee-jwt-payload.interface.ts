export interface EmployeeJwtPayload {
  username: string;
  pharmacyId: number;
}
