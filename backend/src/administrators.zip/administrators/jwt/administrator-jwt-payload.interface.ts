export interface AdministratorJwtPayload {
  username: string;
}
